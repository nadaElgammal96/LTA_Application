package com.fym.lta.DAO;


import com.fym.lta.DTO.RoleScreenDto;

import java.util.Collections;
import java.util.List;

public class RoleScreenDaoImpl implements RoleScreenDao {
    public boolean isExist(RoleScreenDto rs) {
        return false;
    }

    public boolean createNew(RoleScreenDto rs) {
        return false;
    }

    public boolean delete(RoleScreenDto rs) {
        return false;
    }

    public RoleScreenDto searchFor(int id) {
        return null;
    }

    public boolean update(RoleScreenDto rs) {
        return false;
    }

    public List<RoleScreenDto> viewAll() {
        return Collections.emptyList();
    }
}
