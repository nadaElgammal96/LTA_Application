package com.fym.lta.DAO;



import java.util.Collections;
import java.util.List;
import com.fym.lta.DTO.CourseDto;

public class CourseDaoImpl implements CourseDao {
    public Boolean isExist(CourseDto c) {
        return null;
    }

    public CourseDto searchFor(String code) {
        return null;
    }

    public Boolean delete(CourseDto c) {
        return null;
    }

    public List<CourseDto> viewAll() {
        return Collections.emptyList();
    }

    public Boolean update(CourseDto c) {
        return null;
    }

    public Boolean createNew(CourseDto c) {
        return null;
    }
}
