package com.fym.lta.DAO;


import com.fym.lta.DTO.EquipTypeSpecDetailsDto;
import com.fym.lta.DTO.EquipmentDto;
import com.fym.lta.DTO.EquipmentTypeDto;
import com.fym.lta.DTO.RoleDto;

import com.fym.lta.DTO.UserDto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.management.relation.Role;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetProvider;

public class RoleDaoImpl implements RoleDao {
    public Boolean update(RoleDto r) {
        return null;
    }

    public Boolean createNew(RoleDto r) {
        try{JdbcRowSet jdbc = RowSetProvider.newFactory().createJdbcRowSet();
    
                  jdbc.setUrl("jdbc:oracle:thin:@127.0.0.1:1521:xe");
                  jdbc.setUsername("lta");
                  jdbc.setPassword("lta");
                  jdbc.setCommand("insert into ROLE( ROLE.ID_ROLE, ROLE.NAME_ROLE, ROLE.DESCRIPTION_ROLE) values(?, ?, ?)");
                  jdbc.setInt(1,r.getId());
                  jdbc.setString(2,r.getName());
                  jdbc.setString(3,r.getDescription());
                  jdbc.execute();
                  return true;
        }
        catch(Exception e){
            e.printStackTrace();
        return false;
        }
        }
    public Boolean isExist(RoleDto r) {
        boolean flag = false;
               try(JdbcRowSet jdbc = RowSetProvider.newFactory().createJdbcRowSet();) 
               {
                   jdbc.setUrl("jdbc:oracle:thin:@127.0.0.1:1521:xe");
                   jdbc.setUsername("lta");
                   jdbc.setPassword("lta"); 
                   jdbc.setCommand("SELECT ROLE.ID_ROLE FROM ROLE where ROLE.ID_ROLE=?");
                   jdbc.setInt(1,r.getId());
                   jdbc.execute();
                   while(jdbc.next()){
                       flag = true;
                       break;
                       }
                   return flag;
               }
               catch(Exception e){
                   e.printStackTrace();
                   return false;
                   }
    }
    public List<RoleDto> viewAll() {
        List<RoleDto> role = null;
        try{JdbcRowSet jdbc = RowSetProvider.newFactory().createJdbcRowSet();
            
                  jdbc.setUrl("jdbc:oracle:thin:@127.0.0.1:1521:xe");
                  jdbc.setUsername("lta");
                  jdbc.setPassword("lta");
                  jdbc.setCommand("select , USER_TABLE.ID_ROLE, " + "USER_TABLE.NAME_ROLE" + 
                                  "USER_TABLE.DESCRIPTION_ROLE" + 
                                  "from ROLE_TABLE");
                  jdbc.execute();
                  RoleDto ro = null;
                  while(jdbc.next()){
                      if(role == null){
                    role = new ArrayList<>();
        }
                      ro= new RoleDto();
                      ro.setId(jdbc.getInt("ID_ROLE"));
                      ro.setName        (jdbc.getString("NAME_ROLE"));
                      ro.setDescription (jdbc.getString("DESCRIPTION_ROLE"));
                      role.add(ro);
                      ro= null;
        }
              }
              catch(Exception e){
                  e.printStackTrace();
              }
              return role;
        }
    public List<RoleDto> searchFor(RoleDto role) {
        List<RoleDto> roles = null;
            
                try(JdbcRowSet jdbc = RowSetProvider.newFactory().createJdbcRowSet();) {
                    jdbc.setUrl("jdbc:oracle:thin:@127.0.0.1:1521:xe");
                    jdbc.setUsername("lta");
                    jdbc.setPassword("lta");
                    jdbc.setCommand("select ROLE.ID_ROLE, ROLE.NAME_ROLE, ROLE.DESCRIPTION_ROLE" + "from ROLE where ROLE.ID_ROLE=? | ROLE.NAME_ROLE=? | ROLE.DESCRIPTION_ROLE=?");
                    jdbc.setInt(1,Integer.parseInt(role.getSearch()));
                    jdbc.setString(2,role.getSearch());
                    jdbc.setString(3,role.getSearch());
                    jdbc.execute();
                    RoleDto R = null;
                    while(jdbc.next()) {
                        if (roles == null){
                        roles = new ArrayList<>();   
                        }
                        R = new RoleDto();
                        
                    R.setId(jdbc.getInt("ID_ROLE"));
                    R.setName(jdbc.getString("NAME_ROLE"));
                    R.setDescription(jdbc.getString("DESCRIPTION_ROLE"));
                          roles.add(R);
                           R= null;
          }
 }
                   catch(Exception e){
                    e.printStackTrace();
                    }
                return roles;
            }

    public Boolean delete(RoleDto r) {
        try(JdbcRowSet jdbc = RowSetProvider.newFactory().createJdbcRowSet();) {
                   jdbc.setUrl("jdbc:oracle:thin:@127.0.0.1:1521:xe");
                   jdbc.setUsername("lta");
                   jdbc.setPassword("lta");
                   jdbc.setCommand("delete from ROLE_TABLE where ROLE.ID_ROLE = ?  ");
                   jdbc.setInt(1,r.getId());
                   jdbc.execute();
                   return true;
               }
               catch(Exception e){
                   e.printStackTrace();
                   return false;
    }
}

    }