package com.fym.lta.DAO;

import com.fym.lta.DTO.ScheduleSlotDto;

import java.util.Collections;
import java.util.List;

public class ScheduleSlotDaoImpl implements ScheduleSlotDao {
    public Boolean update(ScheduleSlotDto ss) {
        return null;
    }

    public List<ScheduleSlotDto> viewAll() {
        return Collections.emptyList();
    }

    public Boolean isExist(ScheduleSlotDto ss) {
        return null;
    }

    public Boolean createNew(ScheduleSlotDto ss) {
        return null;
    }

    public Boolean delete(ScheduleSlotDto ss) {
        return null;
    }

    public ScheduleSlotDto searchFor(int id) {
        return null;
    }
}
