package com.fym.lta.DAO;

import com.fym.lta.DTO.StageDto;

import java.util.Collections;
import java.util.List;

public class StageDaoImpl implements StageDao {
    public Boolean createNew(StageDto st) {
        return null;
    }

    public Boolean isExist(StageDto st) {
        return null;
    }

    public StageDto searchFor(String code) {
        return null;
    }

    public Boolean delete(StageDto st) {
        return null;
    }

    public List<StageDto> viewAll() {
        return Collections.emptyList();
    }

    public Boolean update(StageDto st) {
        return null;
    }
}
