package com.fym.lta.DAO;

import com.fym.lta.DTO.LocationDto;

import java.util.Collections;
import java.util.List;

public class LocationDaoImpl implements LocationDao {
    public Boolean delete(LocationDto l) {
        return null;
    }

    public Boolean createNew(LocationDto l) {
        return null;
    }

    public LocationDto searchFor(String c) {
        return null;
    }

    public Boolean update(LocationDto l) {
        return null;
    }

    public Boolean isExist(LocationDto l) {
        return null;
    }

    public List<LocationDto> viewAll() {
        return Collections.emptyList();
    }
}
