package com.fym.lta.DAO;

import com.fym.lta.DTO.UserDto;

import java.util.Collections;
import java.util.List;

public class UserDaoImpl implements UserDao {
    public Boolean createNew(UserDto u) {
        return null;
    }

    public Boolean delete(UserDto u) {
        return null;
    }

    public Boolean isExist(UserDto u) {
        return null;
    }

    public UserDto searchFor(String username) {
        return null;
    }

    public List<UserDto> viewAll() {
        return Collections.emptyList();
    }

    public Boolean update(UserDto u) {
        return null;
    }
}
