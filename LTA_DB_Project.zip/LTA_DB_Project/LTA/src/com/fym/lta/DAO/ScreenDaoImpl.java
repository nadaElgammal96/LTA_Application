package com.fym.lta.DAO;

import com.fym.lta.DTO.ScreenDto;

import java.util.Collections;
import java.util.List;

public class ScreenDaoImpl implements ScreenDao {
    public Boolean delete(ScreenDto sc) {
        return null;
    }

    public ScreenDto searchFor(int id) {
        return null;
    }

    public Boolean createNew(ScreenDto sc) {
        return null;
    }

    public Boolean update(ScreenDto sc) {
        return null;
    }

    public Boolean isExist(ScreenDto sc) {
        return null;
    }

    public List<ScreenDto> viewAll() {
        return Collections.emptyList();
    }
}
