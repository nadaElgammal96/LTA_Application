package com.fym.lta.DAO;

import com.fym.lta.DTO.FacultyDto;

import java.util.List;

public class FacultyDaoImpl implements FacultyDao {
    
    
    public Boolean update(FacultyDto f)
    {
       return null; 
    }

    public  FacultyDto  searchFor(String c)
    {
       return null; 
    }
    
    public  Boolean isExist(FacultyDto  f)
    {
       return null; 
    }

    public  List<FacultyDto> viewAll()
    {
       return null; 
    }

    public  Boolean delete(FacultyDto  f)
    {
       return null; 
    }

    public  Boolean createNew(FacultyDto  f)
    {
       return null; 
    }
}
