package com.fym.lta.DAO;


import com.fym.lta.DTO.*;

import java.util.Collections;
import java.util.List;

public class FloorDaoImpl implements FloorDao {
    public Boolean createNew(FloorDto f1) {
        return null;
    }

    public Boolean delete(FloorDto f2) {
        return null;
    }

    public Boolean update(FloorDto f) {
        return null;
    }

    public List<BuildingDto> viewAll() {
        return Collections.emptyList();
    }

    public FloorDto searchFor(String c) {
        return null;
    }

    public Boolean isExist(FloorDto f) {
        return null;
    }
}
