package com.fym.lta.DAO;

import com.fym.lta.DTO.ScheduleDto;

import java.util.Collections;
import java.util.List;

public class ScheduleDaoImpl implements ScheduleDao {
    public Boolean createNew(ScheduleDto sch) {
        return null;
    }

    public Boolean isExist(com.fym.lta.DTO.ScheduleDto sch) {
        return null;
    }

    public List<com.fym.lta.DTO.ScheduleDto> viewAll() {
        return Collections.emptyList();
    }

    public Boolean delete(com.fym.lta.DTO.ScheduleDto sch) {
        return null;
    }

    public Boolean update(com.fym.lta.DTO.ScheduleDto sch) {
        return null;
    }

    public com.fym.lta.DTO.ScheduleDto searchFor(int id) {
        return null;
    }
}
