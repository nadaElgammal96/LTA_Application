package com.fym.lta.DAO;

import com.fym.lta.DTO.SlotDto;

import java.util.Collections;
import java.util.List;

public class SlotDaoImpl implements SlotDao {
    
    
    public List<SlotDto> viewAll() {
        return Collections.emptyList();
    }

    public Boolean createNew(SlotDto s) {
        return null;
    }

    public Boolean isExist(SlotDto s) {
        return null;
    }

    public Boolean delete(SlotDto s) {
        return null;
    }

    public Boolean update(SlotDto s) {
        return null;
    }

    public SlotDto searchFor(String code) {
        return null;
    }
}
