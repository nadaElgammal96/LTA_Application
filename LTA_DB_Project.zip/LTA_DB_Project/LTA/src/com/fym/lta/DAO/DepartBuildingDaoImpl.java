package com.fym.lta.DAO;


import com.fym.lta.DTO.DepartBuildingDto;
import java.util.Collections;
import java.util.List;

public class DepartBuildingDaoImpl implements DepartBuildingDao {
    public Boolean delete (DepartBuildingDto bd) {
        return null;
    }

    public DepartBuildingDto searchFor(String c) {
        return null;
    }

    public List<DepartBuildingDto> viewAll() {
        return Collections.emptyList();
    }

    public Boolean update(DepartBuildingDto bd) {
        return null;
    }

    public Boolean createNew(DepartBuildingDto bd) {
        return null;
    }
    
    public Boolean isExist(DepartBuildingDto bd){return null;}
}
