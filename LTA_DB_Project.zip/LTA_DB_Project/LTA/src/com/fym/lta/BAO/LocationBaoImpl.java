package com.fym.lta.BAO;

import com.fym.lta.DTO.LocationDto;
import com.fym.lta.DTO.SlotDto;

public class LocationBaoImpl implements LocationBao {
    public void viewAllEquipments() {
    }

    public boolean isAvailable(SlotDto slot) {
        return false;
    }

    public boolean delete(LocationDto l) {
        return false;
    }

    public void searchFor(String code) {
    }

    public boolean save(LocationDto l) {
        return false;
    }
}
