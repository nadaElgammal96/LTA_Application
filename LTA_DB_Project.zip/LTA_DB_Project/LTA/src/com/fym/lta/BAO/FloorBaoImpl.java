package com.fym.lta.BAO;

import com.fym.lta.DTO.FloorDto;

public class FloorBaoImpl implements FloorBao {
    public void ListAll() {
    }

    public void ListEmptyLocations(FloorDto floor) {
    }

    public boolean udate(String code) {
        return false;
    }

    public Boolean save(FloorDto floor) {
        return null;
    }

    public Boolean delete(FloorDto floor) {
        return null;
    }

    public void searchForDep(String code) {
    }

    public void ListAllLocations(FloorDto floor) {
    }
}
