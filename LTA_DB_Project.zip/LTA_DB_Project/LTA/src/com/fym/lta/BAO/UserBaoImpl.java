package com.fym.lta.BAO;

import com.fym.lta.DTO.UserDto;

public class UserBaoImpl implements UserBao {
    public void viewAll() {
    }

    public boolean update(String username) {
        return false;
    }

    public boolean add(UserDto u) {
        return false;
    }

    public boolean delete(UserDto u) {
        return false;
    }

    public UserDto searchFor(String username) {
        return null;
    }
}
