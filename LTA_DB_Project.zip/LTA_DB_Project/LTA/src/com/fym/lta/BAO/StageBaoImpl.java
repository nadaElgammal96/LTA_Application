package com.fym.lta.BAO;

import com.fym.lta.DTO.StageDto;

public class StageBaoImpl implements StageBao {
    public boolean update(StageDto S) {
        return false;
    }

    public void viewAll() {
    }

    public void viewCourses() {
    }

    public boolean add(StageDto s) {
        return false;
    }

    public void viewDepartment() {
    }

    public void searchFor(String code) {
    }

    public boolean delete(StageDto s) {
        return false;
    }
}
