package com.fym.lta.BAO;

public class FacultyBaoImpl implements FacultyBao {
    public boolean update() {
        return false;
    }

    public void viewDepartments() {
    }

    public void vieStages() {
    }
}
