package com.fym.lta.BAO;

public abstract interface FacultyBao {
    public abstract boolean update();

    public abstract void viewDepartments();

    public abstract void vieStages();
}
