package com.fym.lta.BAO;

import com.fym.lta.DTO.DepartmentDto;
import com.fym.lta.DTO.StaffDto;


public class StaffBaoImpl implements StafffBao {
    UserBaoImpl endUserBaoImpl;

    public void viewAll() {
    }

    public void searchFor(DepartmentDto dep) {
    }

    public void viewCourses(String ssn) {
    }

    public boolean delete(StaffDto s) {
        return false;
    }

    public void searchFor(String ssn) {
    }

    public boolean add(StaffDto s) {
        return false;
    }

    public boolean update(StaffDto s) {
        return false;
    }

    public float calcWorkHrs() {
        return 0.0f;
    }
}
