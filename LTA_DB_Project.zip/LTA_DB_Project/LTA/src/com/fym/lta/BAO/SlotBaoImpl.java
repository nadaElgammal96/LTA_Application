package com.fym.lta.BAO;

import com.fym.lta.DTO.DepartmentDto;
import com.fym.lta.DTO.SlotDto;

public class SlotBaoImpl implements SlotBao {
    public boolean delete(SlotDto s) {
        return false;
    }

    public boolean add(SlotDto s) {
        return false;
    }

    public SlotDto searchFor(SlotDto s) {
        return null;
    }

    public void viewAll() {
    }

    public boolean update(SlotDto s) {
        return false;
    }

    public void viewAvailableLocations(DepartmentDto d) {
    }

    public void viewAllAvailableLocations() {
    }
}
