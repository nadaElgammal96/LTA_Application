package com.fym.lta.BAO;

import com.fym.lta.DTO.ScheduleDto;

public class ScheduleBaoImpl implements ScheduleBao {
    public void viewAll() {
    }

    public boolean update(ScheduleDto s) {
        return false;
    }

    public boolean add(ScheduleDto s) {
        return false;
    }

    public void searchFor(int i) {
    }

    public void uploadFile() {
    }
}
